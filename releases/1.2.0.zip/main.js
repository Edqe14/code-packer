const meta = require('./meta.json');

console.log('Hello world!');
console.log('This is a dummy program, version ' + meta.version);